import { Modal, Button, Form } from 'react-bootstrap';

const AddFriendModal = ({ show, handleClose, newFriend, setNewFriend, addNewFriend }) => {
  return (
    <Modal show={show} onHide={handleClose}>
      <Modal.Header closeButton>
        <Modal.Title>Add New Friend</Modal.Title>
      </Modal.Header>
      <Modal.Body>
        <Form>
          <Form.Group className="mb-3">
            <Form.Label>Name</Form.Label>
            <Form.Control
              type="text"
              value={newFriend.name}
              onChange={(e) => setNewFriend({ ...newFriend, name: e.target.value })}
            />
          </Form.Group>
          <Form.Group className="mb-3">
            <Form.Label>Close Friend</Form.Label>
            <Form.Check
              type="checkbox"
              checked={newFriend.isCloseFriend}
              onChange={(e) => setNewFriend({ ...newFriend, isCloseFriend: e.target.checked })}
            />
          </Form.Group>
        </Form>
      </Modal.Body>
      <Modal.Footer>
        {/* Remove the Cancel button */}
        <Button
          variant="dark"
          onClick={addNewFriend}
          className="w-100 btn-lg" // Make the button large and centered
        >
          Add Friend
        </Button>
      </Modal.Footer>
    </Modal>
  );
};

export default AddFriendModal;
