import React from 'react';
import { Row } from 'react-bootstrap';
import FriendItem from './FriendItem';

const FriendList = ({ friends, title, showNoFriendsMessage = false, toggleCloseFriend }) => (
  <div className="mb-4">
    <h5 className="mb-3">{title}</h5>
    {friends.length > 0 ? (
      <Row>
        {friends.map(friend => (
          <FriendItem 
            key={friend.id} 
            friend={friend} 
            toggleCloseFriend={toggleCloseFriend} 
          />
        ))}
      </Row>
    ) : (
      showNoFriendsMessage && (
        <div className="text-center py-4">
          No friend found with this name
        </div>
      )
    )}
  </div>
);

export default FriendList;
