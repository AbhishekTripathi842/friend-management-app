import React from 'react';
import { Col, Form, Image } from 'react-bootstrap';

const FriendItem = ({ friend, toggleCloseFriend }) => (
  <Col md={6} key={friend.id} className="mb-2">
    <div className="d-flex align-items-center p-2 bg-light rounded">
      <Image
        src={friend.avatar || 'https://www.google.com/images/branding/googlelogo/1x/googlelogo_color_272x92dp.png'}
        roundedCircle
        width={40}
        height={40}
        className="me-2"
      />
      <div>
        <div>{friend.name}</div>
      </div>
      <Form.Check
        type="checkbox"
        className="ms-auto"
        checked={friend.isCloseFriend}
        onChange={() => toggleCloseFriend(friend.id)}
      />
    </div>
  </Col>
);

export default FriendItem;
