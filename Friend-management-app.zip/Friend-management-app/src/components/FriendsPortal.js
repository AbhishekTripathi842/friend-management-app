import React, { useState } from 'react';
import { Container, Form, Button, Image } from 'react-bootstrap';
import FriendList from './FriendList';
import AddFriendModal from './AddFriendModal';
import 'bootstrap/dist/css/bootstrap.min.css';

const FriendsPortal = () => {
  const [searchTerm, setSearchTerm] = useState('');
  const [showAddFriend, setShowAddFriend] = useState(false);
  const [newFriend, setNewFriend] = useState({ name: '', avatar: '', isCloseFriend: false });
  const [friends, setFriends] = useState([
    { id: 1, name: 'Neha Sharma', isCloseFriend: true, avatar: 'https://randomuser.me/api/portraits/women/1.jpg' },
    { id: 2, name: 'Nisha Mishra', isCloseFriend: true, avatar: 'https://randomuser.me/api/portraits/women/2.jpg' },
    { id: 3, name: 'Abhay Thakur', isCloseFriend: false, avatar: 'https://randomuser.me/api/portraits/men/1.jpg' },
    { id: 4, name: 'Mohini Garg', isCloseFriend: false, avatar: 'https://randomuser.me/api/portraits/women/3.jpg' },
  ]);

  const toggleCloseFriend = (friendId) => {
    setFriends(friends.map(friend => 
      friend.id === friendId 
        ? { ...friend, isCloseFriend: !friend.isCloseFriend }
        : friend
    ));
  };

  const addNewFriend = () => {
    if (friends.some(friend => friend.name.toLowerCase() === newFriend.name.toLowerCase())) {
      alert('Friend with this name already exists!');
      return;
    }
    const newId = Math.max(...friends.map(f => f.id)) + 1;
    const newFriendWithAvatar = {
      ...newFriend,
      id: newId,
      avatar: newFriend.avatar || `https://randomuser.me/api/portraits/men/${Math.floor(Math.random() * 10) + 1}.jpg`,
    };
    setFriends([...friends, newFriendWithAvatar]);
    setShowAddFriend(false);
    setNewFriend({ name: '', avatar: '', isCloseFriend: false });
  };

  const filteredFriends = friends.filter(friend => 
    friend.name.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const closeFriends = filteredFriends.filter(friend => friend.isCloseFriend);
  const allFriends = filteredFriends;

  return (
    <Container className="py-4 bg-white rounded shadow">
      <div className="d-flex align-items-center mb-4">
        <div className="d-flex align-items-center me-3">
          <Image
            src="https://randomuser.me/api/portraits/men/6.jpg"
            roundedCircle
            width={60}
            height={60}
            className="me-3"
          />
          <div>
            <h6 className="mb-0">Abhishek Tripathi</h6>
            <small className="text-muted">Abhishektripathi842@gmail.com</small>
          </div>
        </div>
        <Button variant="link" className="ms-auto">
          Logout
        </Button>
      </div>

      <div className="d-flex justify-content-between align-items-center mb-4">
        <Form.Control
          type="search"
          placeholder="Search"
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
          className="w-75"
        />
        <Button variant="dark" size="sm" onClick={() => setShowAddFriend(true)}>
          Add Friend
        </Button>
      </div>

      <FriendList 
        friends={closeFriends} 
        title="Close Friends" 
        showNoFriendsMessage={searchTerm.length > 0}
        toggleCloseFriend={toggleCloseFriend} 
      />
      <FriendList 
        friends={allFriends} 
        title="All Friends"
        toggleCloseFriend={toggleCloseFriend} 
      />

      <AddFriendModal 
        show={showAddFriend} 
        handleClose={() => setShowAddFriend(false)} 
        newFriend={newFriend} 
        setNewFriend={setNewFriend} 
        addNewFriend={addNewFriend}
      />
    </Container>
  );
};

export default FriendsPortal;
