import FriendsPortal from './components/FriendsPortal'
import 'bootstrap/dist/css/bootstrap.min.css';

const App = () => {
 

  return (
    <FriendsPortal/>
  );
};

export default App;